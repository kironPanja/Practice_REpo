s/ WB/, West Bengal/
s/ BH/, Bihar/
s/ MH/, Maharashtra/
