echo ''[Dhello friends'
