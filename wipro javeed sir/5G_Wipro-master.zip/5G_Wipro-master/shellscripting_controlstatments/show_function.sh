


showDate()
{

  echo "User: `whoami` ";


}


showDate
