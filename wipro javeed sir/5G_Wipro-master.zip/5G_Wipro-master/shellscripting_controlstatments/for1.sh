for  x  in  1 2 3 4 5
		 
		 do
			 		  
			 		 echo "The value of X is : $x"
					 		  
					 	 done
						 
