 for  file  in   *.sh
	  
	         do
			  
	echo   $file
					  
done
