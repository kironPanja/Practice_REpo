echo 'Hello friends'
