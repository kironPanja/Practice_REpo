until  false
		 
		        do
						ps  -a
											 
								  sleep 2
								  						 
							  done


