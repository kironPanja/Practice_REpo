



echo "Hello friends"
echo "Enter your name"
read   name
echo   $name
 
