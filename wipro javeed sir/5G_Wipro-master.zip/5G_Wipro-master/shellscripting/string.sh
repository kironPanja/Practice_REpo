
str="javeed"

#here -n check str is not null

if  test  -n $str;   then
		echo "str value is $str , its not null"

fi	

#here -z check str is null

str2=$null

if  test  -z  $str2;  then
		 echo "str2 value is NULL"
fi	 

