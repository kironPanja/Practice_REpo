


echo  Program Name: $0


 grep "$1"  $2


 echo "\n End of script"


