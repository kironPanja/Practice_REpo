echo 'Enter your name'
read name

echo "Thank you $name  sir"
