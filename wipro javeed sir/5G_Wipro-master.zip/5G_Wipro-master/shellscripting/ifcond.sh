#Initializing two variables 
a=10 
b=10 
c=30
  
#Check whether they are equal 
if [ $a == $b ] 
then 
    echo "a is equal to b"
fi 
  
#Check whether they are not equal 
if [ $a != $c ] 
then 
    echo "a is not equal to c"
fi 
