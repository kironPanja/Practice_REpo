name="javeed"
salary=9000

echo  "Welcome  $name"
echo  "Salary is:  $salary"


flag=true

echo "Is it working  : $flag"


