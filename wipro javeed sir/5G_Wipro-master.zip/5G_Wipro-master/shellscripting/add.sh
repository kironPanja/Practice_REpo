
echo 'Enter N1 value'
read n1

echo 'Enter N2 value'
read n2

 let result=n1+n2

 echo "Result is : $result"
