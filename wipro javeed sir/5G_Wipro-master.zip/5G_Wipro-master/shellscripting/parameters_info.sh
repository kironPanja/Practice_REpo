


echo  $0

echo  "Number of arguments  $#"

echo "Arguments list $*"

echo $1
echo $2
echo $3





