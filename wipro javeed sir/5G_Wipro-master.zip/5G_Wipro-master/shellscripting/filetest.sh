



echo "enter file"

read fname

if [ -r $fname ]

then

echo "file is readable"

fi         

